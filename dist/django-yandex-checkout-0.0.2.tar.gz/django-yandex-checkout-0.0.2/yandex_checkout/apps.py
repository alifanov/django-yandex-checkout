from django.apps import AppConfig


class YandexCheckoutConfig(AppConfig):
    name = 'yandex_checkout'
